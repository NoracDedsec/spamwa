# Spam Wa
![IMG_20200202_195322](https://user-images.githubusercontent.com/59508497/73608456-b8536a80-45f5-11ea-8458-50817c3088a2.JPG)

```
Indonesia :
Kode Ini Dibuat Untuk Menjahili Teman Kalian :v
```
```
Inggris : 
This Code Was Made To Make Your Friends Joke: v
```
# Penginstalan
```
$ pkg install git
$ pkg install python2
$ pip2 install requests
$ git clone https://github.com/Fukur0-3XP/SpamWa
$ cd SpamWa
$ python2 Wa.py
```

# Info
```
Creator : ./FUKUR0-3XP
Team : Black Coders Anonymous Satanic Exploiter Team

Instagram : ricko.3xp_
Email : 3xp.fukur0@gmail.com
```
